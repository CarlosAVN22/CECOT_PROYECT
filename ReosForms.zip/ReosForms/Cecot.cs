﻿namespace CECOT_PROYECT.Resources
{
    public class Cecot
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Edad { get; set; }
        public string Delito { get; set; }

        public string DUI { get; set; }
        public string Sentencia { get; set; }

        public int IdCelda { get; set; }
        public string NombreCelda { get; set; }         // Solo si usas nombre personalizado
        public string NombreSeccion { get; set; }       // Desde tabla Secciones
        public string TipoSeccion { get; set; }         // Desde tabla Secciones

        public string FechaIngreso { get; set; }

        public Cecot() { }

        public Cecot(int id, string nombre, string edad, string delito, string dui, string sentencia, string fechaIngreso)
        {
            Id = id;
            Nombre = nombre;
            Edad = edad;
            Delito = delito;
            DUI = dui;
            Sentencia = sentencia;
            FechaIngreso = fechaIngreso;
        }
    }
}


