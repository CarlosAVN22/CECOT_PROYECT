﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CECOT_PROYECT.Resources
{
    public class cecotAgregar
    {
        public static int AgregarPersona(Cecot persona)
        {
            int retorna = 0;
            try
            {
                using (SqlConnection conexion = conexionBD.ObtenerConexion())
                {
                    string query = @"
                        INSERT INTO Reos 
                        (Nombre, Edad, Delito, DUI, Sentencia, FechaIngreso, IdCelda) 
                        VALUES 
                        (@Nombre, @Edad, @Delito, @DUI, @Sentencia, @FechaIngreso, @IdCelda)";

                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {
                        cmd.Parameters.AddWithValue("@Nombre", persona.Nombre);
                        cmd.Parameters.AddWithValue("@Edad", persona.Edad);
                        cmd.Parameters.AddWithValue("@Delito", persona.Delito);
                        cmd.Parameters.AddWithValue("@DUI", persona.DUI);
                        cmd.Parameters.AddWithValue("@Sentencia", persona.Sentencia);
                        cmd.Parameters.AddWithValue("@FechaIngreso", persona.FechaIngreso);
                        cmd.Parameters.AddWithValue("@IdCelda", persona.IdCelda);

                        retorna = cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al insertar: " + ex.Message);
            }
            return retorna;
        }

        public static bool ActualizarPersona(Cecot persona)
        {
            bool actualizado = false;
            try
            {
                using (SqlConnection conexion = conexionBD.ObtenerConexion())
                {
                    string query = @"
                        UPDATE Reos 
                        SET Nombre = @Nombre,
                            Edad = @Edad,
                            Delito = @Delito,
                            DUI = @DUI,
                            Sentencia = @Sentencia,
                            FechaIngreso = @FechaIngreso,
                            IdCelda = @IdCelda
                        WHERE Id = @Id";

                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {
                        cmd.Parameters.AddWithValue("@Id", persona.Id);
                        cmd.Parameters.AddWithValue("@Nombre", persona.Nombre);
                        cmd.Parameters.AddWithValue("@Edad", persona.Edad);
                        cmd.Parameters.AddWithValue("@Delito", persona.Delito);
                        cmd.Parameters.AddWithValue("@DUI", persona.DUI);
                        cmd.Parameters.AddWithValue("@Sentencia", persona.Sentencia);
                        cmd.Parameters.AddWithValue("@FechaIngreso", persona.FechaIngreso);
                        cmd.Parameters.AddWithValue("@IdCelda", persona.IdCelda);

                        actualizado = cmd.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar: " + ex.Message);
            }
            return actualizado;
        }

        public static List<Cecot> PresentarRegistros()
        {
            List<Cecot> lista = new List<Cecot>();

            using (SqlConnection conexion = conexionBD.ObtenerConexion())
            {
                string query = @"
                    SELECT 
                        R.Id, R.Nombre, R.Edad, R.DUI, R.Sentencia, R.Delito, 
                        R.FechaIngreso, C.Id AS IdCelda, 
                        S.Nombre AS NombreSeccion, S.Tipo AS TipoSeccion
                    FROM Reos R
                    INNER JOIN Celdas C ON R.IdCelda = C.Id
                    INNER JOIN Secciones S ON C.IdSeccion = S.Id";

                SqlCommand comando = new SqlCommand(query, conexion);
                SqlDataReader reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    Cecot reo = new Cecot
                    {
                        Id = reader.GetInt32(0),
                        Nombre = reader.GetString(1),
                        Edad = reader.GetString(2),
                        DUI = reader.GetString(3),
                        Sentencia = reader.GetString(4),
                        Delito = reader.GetString(5),
                        FechaIngreso = reader.GetDateTime(6).ToShortDateString(),
                        IdCelda = reader.GetInt32(7),
                        NombreSeccion = reader.GetString(8),
                        TipoSeccion = reader.GetString(9)
                    };

                    lista.Add(reo);
                }
                conexion.Close();
            }

            return lista;
        }

        public static bool EliminarRegistro(int idReo)
        {
            try
            {
                using (SqlConnection conexion = conexionBD.ObtenerConexion())
                {
                    string query = "DELETE FROM Reos WHERE Id = @Id";
                    using (SqlCommand comando = new SqlCommand(query, conexion))
                    {
                        comando.Parameters.AddWithValue("@Id", idReo);
                        return comando.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar: " + ex.Message);
                return false;
            }
        }
    }
}


